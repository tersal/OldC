#include "serial.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#define TIMEOUT 500000

int main(int argc, char *argv[]){
	printf("Contador de personas V0.1 © 2013, Daniel Delgado <daniel.delgado@globalcorporation.cc>\n");
	int puerto_lector;
	int resp;
	char datos[2];
	abrir_puerto(&puerto_lector);
	long personas_total=0;
	int arriba=0;
	while(1){
		fflush(stdout);
		resp=serial_read(puerto_lector,datos,2, TIMEOUT );
/*		printf("Resp: %d \n",resp);*/
/*		if (resp==2) continue;*/
		if (datos[0]=='+'){
			personas_total++;
			arriba++;
			printf("Personas total:\t%d \tA bordo:%d\n",personas_total,arriba);
		}
		else if(datos[0]=='-'){
			if (arriba-1>=0)
				arriba--;
			printf("Personas total:\t%d \tA bordo:%d\n",personas_total,arriba);
		}
		
	}
	serial_close(puerto_lector);
	return 0;
}
