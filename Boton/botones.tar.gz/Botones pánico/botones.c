#include "serial.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <string.h>

#define TIMEOUT 500000

int abrir_socket();
char *get_ip(char *host);
char *build_query(char *host, char *page);
void senal(char *host, char *page, int valor);

int main(int argc, char *argv[]){
	printf("Lector de botones de pánico V0.1 © 2013, Daniel Delgado <daniel.delgado@globalcorporation.cc>\n");
//	struct sockaddr_in *server;
//	int sock;
//	char *ip;
	char *host = "192.168.2.250";
	char *page = "Services/Json/eDemo/DroneService.svc/UpdateNetworkDrone/";
//	char buf[BUFSIZ+1];
//	int tmpres;
//	char *post;
	int puerto_lector;
	int resp;
	char datos[5];
	char device[]="/dev/ttyUSB0";
	abrir_puerto(&puerto_lector,device);

	while(1){
		fflush(stdout);
		resp=serial_read(puerto_lector,datos,5, TIMEOUT ); //Recibe 'SOS1','SOS2' o 'SOS3' por lo que sólo importa leer el cuarto valor
		if (resp==5){
			switch (datos[3]){

	/*En cada uno de los case podrían agregar su comunicación con servidor*/
	/*Pueden quitar los pritfs por lo que quieran, no son necesarios.*/


	
				case '1':	printf("Botón 1 presionado, parte 1 del camión\n"); 
					 senal(host, page, 1);
					 break;
				case '2':	printf("Botón 2 presionado, parte 2 del camión\n");
					 senal(host, page, 2);
					 break;
				case '3':	printf("Botón 3 presionado, parte 3 del camión\n");
					 senal(host, page, 3);
					 break;
				default : break;
			}
		}
	}
	serial_close(puerto_lector);
	return 0;
}

void senal(char *host, char *page, int valor)
{
 struct sockaddr_in *server;
 int sock;
 char *ip;
 int tmpres;
 char *post;

 sock = abrir_socket();
 ip = get_ip(host);
 server = (struct sockaddr_in *)malloc(sizeof(struct sockaddr_in));
 server->sin_family = AF_INET;
 tmpres = inet_pton(AF_INET, ip, (void *)(&(server->sin_addr.s_addr)));
 if(tmpres < 0)
 {
  perror("\nCan't set server->sin_addr.s_addr");
  exit(1);
 }else if(tmpres == 0)
 {
  fprintf(stderr, "%s is not a valid IP address\n", ip);
  exit(1);
 }
 server->sin_port = htons(80);

 if(connect(sock, (struct sockaddr *)server, sizeof(struct sockaddr)) < 0)
 {
  perror("Could not connect");
  exit(1);
 }
 post = build_query(host, page, valor);

 int enviado = 0;
 while(enviado < strlen(post))
 {
  tmpres = send(sock, post+enviado, strlen(post)-enviado, 0);
  if(tmpres == -1)
  {
   perror("Can't send query");
   exit(1);
  }
  enviado += tmpres;
 }
 free(post);
 free(server);
 free(ip);
 close(sock);
}

int abrir_socket()
{
 int sock;
 if((sock=socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0)
 {
  perror("\nImposible crear socket");
  exit(1);
 }
 return sock;
}

char *get_ip(char *host)
{
 struct hostent *hent;
 int iplen = 15;
 char *ip = (char *)malloc(iplen+1);
 memset(ip, 0, iplen+1);
 if((hent = gethostbyname(host)) == NULL)
 {
  herror("\nCan't get IP");
  exit(1);
 }
 
 if(inet_ntop(AF_INET, (void *)hent->h_addr_list[0], ip, iplen) == NULL )
 {
  perror("\nCan't resolve host");
  exit(1);
 }
 
 return ip;
}

char *build_query(char *host, char *page, int valor)
{
 char *query;
 char *getpage = page;
 char *postdata = "{\"IP\": \"1.2.3.4\", \"DroneID\": 5, \"MAC\": \"Botonazo\"}";
 char *tpl = "POST /%s HTTP/1.0\r\nHost: %s\r\nContent-type: application/json\r\nContent-length: %d\r\n\r\n%s";
 query = (char *)malloc(strlen(host) + strlen(getpage) + strlen(tpl) + strlen(postdata) -5);
 
 sprintf(query, tpl, getpage, host, strlen(postdata), postdata);
 return query;
}
