/*Es recomendable agregar try en las condiciones de Transmit para evitar que se*/
/*salga del programa y con ello deje de funcionar todo en nuestro sistema*/
#include <stdio.h>
#include <stdlib.h>
#include <winscard.h>
#include <reader.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <string.h>

#define TIMEOUT 1000
#define IOCTL_SMARTCARD_VENDOR_IFD_EXCHANGE    SCARD_CTL_CODE(1)

//Comprobación de que las funciones de la API PCSC se ejecuten correctamente
#define CHECK(f, rv) \
 if (SCARD_S_SUCCESS != rv) \
 { \
  printf(f ": %s\n", pcsc_stringify_error(rv)); \
  return -1; \
 }




void doubleToHex(double saldo, BYTE saldo_hex[]){
	int i;
	union{
		double f;
		char c[8];
	} u;
	u.f=saldo;
	for (i=0;i<8;i++){
		saldo_hex[i]=u.c[i];
	}
}
double hexToDouble(BYTE pbRecvBuffer[]){
	int i,j=-1;
	union{
		double f;
		char c[8];
	} u;
	for(i=8;i<16;i++){
		u.c[i+j]=pbRecvBuffer[i];
		j-=2;
	}
	return u.f;
}
void respuesta(DWORD dwRecvLength, BYTE pbRecvBuffer[]){
	int i;
	printf("response: ");
	for(i=0; i<dwRecvLength; i++)
		printf("%02X ", pbRecvBuffer[i]);
	printf("\n");
}

int abrir_socket();
char *get_ip(char *host);
char *build_query(char *host, char *page);

int main(void)
{
	printf("V 1.1 © 2013, Daniel Delgado <daniel.delgado@globalcorporation.cc>\n");
	int i, init=0;
	struct sockaddr_in *remote;
 	int sock;
	char *ip;
	char *host = "192.168.2.250";
	char *page = "Services/Json/eDemo/DroneService.svc/UpdateNetworkDrone/";
	char buf[BUFSIZ+1];
	int tmpres;
	char *post;
	LONG rv;	//Valor devuelto por las funciones de la API
	SCARDCONTEXT hContext;
	LPTSTR mszReaders;	//Nombre del lector
	SCARDHANDLE hCard;	//Número de lector detectado
	DWORD dwReaders, dwActiveProtocol, dwRecvLength;
	DWORD protocoloDesc=-1;
	SCARD_READERSTATE rgReaderStates;
 	SCARD_IO_REQUEST pioSendPci;
	BYTE pbRecvBuffer[258];	//Respuesta de la tarjeta uint8
	double saldo;
	char saldo_lcd[7];
	BYTE saldo_hex[8];
//Comandos LCD
	BYTE cmd_clear_LCD[] = { 0xFF, 0x00, 0x60, 0x00, 0x00 };
	BYTE cmd_global[] = { 0xFF, 0x00, 0x68, 0x00, 0x0D, 0x47, 0x4c, 0x4f, 0x42, 0x41, 0x4c, 0x20, 0x52, 0x45, 0x41, 0x44, 0x45, 0x52};
	BYTE cmd_saldo[]={0xFF, 0x00, 0x68, 0x40, 0x06,	0x53, 0x41, 0x4c, 0x44, 0x4f, 0x3a};
	BYTE cmd_money[]={0xFF, 0x00, 0x68, 0x47, 0x07,	0x53, 0x61, 0x6c, 0x64, 0x6f, 0x3a, 0x00};
	BYTE cmd_insuf[]={0xFF, 0x00, 0x68, 0x47, 0x07,	0x49, 0x4e, 0x53, 0x55, 0x46, 0x49, 0x2e};
	BYTE cmd_read[] = { 0xFF, 0xB0, 0x00, 0x0C, 0x10};
	BYTE cmd_auth_key[] = { 0xFF, 0x82, 0x00, 0x00, 0x06, 0xFF, 0xFF, 0xFF,	0xFF, 0xFF, 0xFF}; //Carga llave
	BYTE cmd_auth_sc[] = { 0xFF, 0x86, 0x00, 0x00, 0x05, 0x01, 0x00, 0x0C, 0x60, 0x00 }; //Autentica bloque
	BYTE cmd_write[]={0xFF,0xD6,0x00,0x10,0x10, 0x00, 0x00,0x00,0x00,0x00,0x00,0x00,0x00, 0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00 };
	BYTE cmd_backlight[] = { 0xFF, 0x00, 0x64, 0xFF, 0x00};


	DWORD nbReaders=1;
	//EStablece contexto
	rv = SCardEstablishContext(SCARD_SCOPE_SYSTEM, NULL, NULL, &hContext);
	CHECK("SCardEstablishContext", rv)
	//Comprueba si la API tiene designación automática de memoria, para este caso lo tiene
#ifdef SCARD_AUTOALLOCATE
	dwReaders = SCARD_AUTOALLOCATE;
	//Regresa lista de lectores de tarjetas
	rv = SCardListReaders(hContext, NULL, (LPTSTR)&mszReaders, &dwReaders);
	CHECK("SCardListReaders", rv)
#else
	rv = SCardListReaders(hContext, NULL, NULL, &dwReaders);
	CHECK("SCardListReaders", rv)
	mszReaders = calloc(dwReaders, sizeof(char));
 	rv = SCardListReaders(hContext, NULL, mszReaders, &dwReaders);
	 CHECK("SCardListReaders", rv)
#endif
	printf("reader name: %s\n", mszReaders);
	 //Termina las inicializaciones 

	 pioSendPci = *SCARD_PCI_T1; //Como sabemos el protocolo que maneja nos evitamos tener que definirlo por lectura

//Se establece un estado inicial de lectura de tarjeta
	rgReaderStates.szReader = mszReaders;
	printf("reader name: %s\n", rgReaderStates.szReader);
	rgReaderStates.dwCurrentState = SCARD_STATE_UNAWARE;
	rv = SCardGetStatusChange(hContext, INFINITE, &rgReaderStates, nbReaders);


//Debería usarse esta condición de manera más consciente para la siguiente versión (yeah, right)
/*	while ((rv == SCARD_S_SUCCESS) || (rv == SCARD_E_TIMEOUT)){*/
	while (1){
		rv = SCardGetStatusChange(hContext, INFINITE, &rgReaderStates, nbReaders);
		rgReaderStates.dwCurrentState =rgReaderStates.dwEventState; //Actualiza valor
/*		printf("reader state: 0x%04X\n", rgReaderStates.dwEventState);*/
		if (rgReaderStates.dwEventState & SCARD_STATE_PRESENT){

			dwRecvLength = sizeof(pbRecvBuffer);
			//NEcesario modificar para evitar que se desborde memoria
			rv = SCardReconnect(hCard, SCARD_SHARE_SHARED, SCARD_PROTOCOL_T0 | SCARD_PROTOCOL_T1,  SCARD_RESET_CARD, &dwActiveProtocol);
			printf("Tarjeta insertada\n ");
			//Rutina de inicialización de parámetros enviados al lector
			if (init==1){
				//Cargar llaves de autenticación en el lector para autenticar las llaves de las tarjetas MIfare
				//Load a key {FF FF FF FF FF FFh} into the key location 0x00h.
				dwRecvLength = sizeof(pbRecvBuffer);
				rv = SCardTransmit(hCard, &pioSendPci, cmd_auth_key, sizeof(cmd_auth_key), NULL, pbRecvBuffer, &dwRecvLength);
				if(rv!=SCARD_S_SUCCESS) continue;
/*				CHECK("SCardTransmit", rv)*/
				respuesta(dwRecvLength, pbRecvBuffer);

				init=2;
			}
			//Escribe Saldo
			dwRecvLength = sizeof(pbRecvBuffer);
			rv = SCardTransmit(hCard, &pioSendPci, cmd_saldo, sizeof(cmd_saldo),	NULL, pbRecvBuffer, &dwRecvLength);
			if(rv!=SCARD_S_SUCCESS) continue;
/*			CHECK("SCardTransmit", rv)*/
/*			respuesta(dwRecvLength, pbRecvBuffer);*/


			//Authenticate Block 0C-0E with the following characteristics: Type A, key number 00h
			cmd_auth_sc[7] = 0x0C;
			dwRecvLength = sizeof(pbRecvBuffer);
			rv = SCardTransmit(hCard, &pioSendPci, cmd_auth_sc, sizeof(cmd_auth_sc), NULL, pbRecvBuffer, &dwRecvLength);
			if(rv!=SCARD_S_SUCCESS) continue;
/*			CHECK("SCardTransmit", rv)*/
/*			respuesta(dwRecvLength, pbRecvBuffer);*/
			printf("Lectura de ID's\n");

			//Leer el bloque 0C,0D,0E
			cmd_read[3]=0xC;
			dwRecvLength = sizeof(pbRecvBuffer);
			rv = SCardTransmit(hCard, &pioSendPci, cmd_read, sizeof(cmd_read), NULL, pbRecvBuffer, &dwRecvLength);
			if(rv!=SCARD_S_SUCCESS) continue;
/*			CHECK("SCardTransmit", rv)*/
			respuesta(dwRecvLength, pbRecvBuffer);
			dwRecvLength = sizeof(pbRecvBuffer);
			 cmd_read[3] = 0x0D;
			rv = SCardTransmit(hCard, &pioSendPci, cmd_read, sizeof(cmd_read), NULL, pbRecvBuffer, &dwRecvLength);
			if(rv!=SCARD_S_SUCCESS) continue;
/*			CHECK("SCardTransmit", rv)*/
			respuesta(dwRecvLength, pbRecvBuffer);
			dwRecvLength = sizeof(pbRecvBuffer);
			 cmd_read[3] = 0x0E;
			rv = SCardTransmit(hCard, &pioSendPci, cmd_read, sizeof(cmd_read), NULL, pbRecvBuffer, &dwRecvLength);
			if(rv!=SCARD_S_SUCCESS) continue;
/*			CHECK("SCardTransmit", rv)*/
			respuesta(dwRecvLength, pbRecvBuffer);

			//Autenticar y leer el saldo anterior
			dwRecvLength = sizeof(pbRecvBuffer);
			cmd_auth_sc[7] = 0x10;
			rv = SCardTransmit(hCard, &pioSendPci, cmd_auth_sc, sizeof(cmd_auth_sc), NULL, pbRecvBuffer, &dwRecvLength);
			if(rv!=SCARD_S_SUCCESS) continue;
/*			CHECK("SCardTransmit", rv)*/
/*			respuesta(dwRecvLength, pbRecvBuffer);*/
			dwRecvLength = sizeof(pbRecvBuffer);
			cmd_read[3] = 0x10;
			rv = SCardTransmit(hCard, &pioSendPci, cmd_read, sizeof(cmd_read), NULL, pbRecvBuffer, &dwRecvLength);
			if(rv!=SCARD_S_SUCCESS) continue;
/*			CHECK("SCardTransmit", rv)*/
/*			respuesta(dwRecvLength, pbRecvBuffer);*/

			saldo=hexToDouble(pbRecvBuffer);
			printf("Saldo anterior:\t%10.2f \n",saldo);



			if (saldo-3>=0){
				//Decremento de saldo
				saldo-=3;
				doubleToHex(saldo,saldo_hex);
				//Escribimos nuevo saldo
				dwRecvLength = sizeof(pbRecvBuffer);
				for (i=13;i<21;i++) cmd_write[i]=saldo_hex[20-i]; //Escribimos los valores de saldo_hex[7-0] en las posic. cmd_write[13-20] para guardar nuevo valor
				rv = SCardTransmit(hCard, &pioSendPci, cmd_write, sizeof(cmd_write), NULL, pbRecvBuffer, &dwRecvLength);	
				if(rv!=SCARD_S_SUCCESS) continue;


/*			Aqui se actualiza se escribe todo lo que tengan que configurar para los servicios web u obtención de información*/
				sock = abrir_socket();
				ip = get_ip(host);
				remote = (struct sockaddr_in *)malloc(sizeof(struct sockaddr_in));
				remote->sin_family = AF_INET;
				tmpres = inet_pton(AF_INET, ip, (void *)(&(remote->sin_addr.s_addr)));
				if( tmpres < 0 )
				{
				 perror("\nCan't set remote->sin_addr.s_addr");
				 exit(1);
				}else if(tmpres == 0)
				{
				 fprintf(stderr, "%s is not a valid IP address\n", ip);
				 exit(1);
				}
				remote->sin_port = htons(80);

				if(connect(sock, (struct sockaddr *)remote, sizeof(struct sockaddr)) < 0)
				{
				 perror("Could not connect");
				 exit(1);
				}
				post = build_query(host, page);

				int sent = 0;
				while(sent < strlen(post))
				{
				 tmpres = send(sock, post+sent, strlen(post)-sent, 0);
				 if(tmpres == -1)
				 {
				  perror("Can't send query");
				  exit(1);
				 }
				 sent += tmpres;
				}
				memset(buf, 0, sizeof(buf));
				free(post);
				free(remote);
				free(ip);
				close(sock);
/*				CHECK("SCardTransmit", rv)*/
/*				respuesta(dwRecvLength, pbRecvBuffer);*/
				printf("Saldo nuevo:\t%10.2f \n",saldo);
				dwRecvLength = sizeof(pbRecvBuffer);
				cmd_read[3] = 0x10;
				rv = SCardTransmit(hCard, &pioSendPci, cmd_read, sizeof(cmd_read), NULL, pbRecvBuffer, &dwRecvLength);
				if(rv!=SCARD_S_SUCCESS) continue;
/*				CHECK("SCardTransmit", rv)*/
/*				respuesta(dwRecvLength, pbRecvBuffer);*/

				for(i=0;i<7;i++) saldo_lcd[i]=0;
				snprintf(saldo_lcd, sizeof(saldo_lcd), "%3.3f", (float)saldo);
				for(i=5;i<12;i++)
					cmd_money[i]=saldo_lcd[i-5];
				dwRecvLength = sizeof(pbRecvBuffer);
				rv = SCardTransmit(hCard, &pioSendPci, cmd_money, sizeof(cmd_money), NULL, pbRecvBuffer, &dwRecvLength);
				if(rv!=SCARD_S_SUCCESS) continue;
/*				CHECK("SCardTransmit", rv)*/
/*				respuesta(dwRecvLength, pbRecvBuffer);	*/
		
				
			}
			else{
				//Desplegar saldo insuficiente:
				dwRecvLength = sizeof(pbRecvBuffer);
				rv = SCardTransmit(hCard, &pioSendPci, cmd_insuf, sizeof(cmd_insuf), NULL, pbRecvBuffer, &dwRecvLength);
			if(rv!=SCARD_S_SUCCESS) continue;
/*				CHECK("SCardTransmit", rv)*/


			}				
		}

		if(rgReaderStates.dwEventState & SCARD_STATE_EMPTY){

/*			printf("No hay tarjeta\n");*/


			if (init==0){
				//Primera conexión con el lector
				rv = SCardConnect(hContext, mszReaders, SCARD_SHARE_DIRECT, SCARD_PROTOCOL_T0 | SCARD_PROTOCOL_T1, &hCard, &protocoloDesc);
				CHECK("SCardConnect", rv)
				//Enciende el led LCD
				dwRecvLength = sizeof(pbRecvBuffer);
				rv = SCardControl(hCard, IOCTL_SMARTCARD_VENDOR_IFD_EXCHANGE, cmd_backlight, sizeof(cmd_backlight),  pbRecvBuffer, dwRecvLength ,&dwRecvLength);
				CHECK("SCardTransmit", rv)

				init=1;
			}

			//Escribe Global \n Saldo actual

			dwRecvLength = sizeof(pbRecvBuffer);
			rv = SCardControl(hCard, IOCTL_SMARTCARD_VENDOR_IFD_EXCHANGE, cmd_clear_LCD , sizeof(cmd_clear_LCD),  pbRecvBuffer, dwRecvLength ,&dwRecvLength);
			dwRecvLength = sizeof(pbRecvBuffer);
			rv = SCardControl(hCard, IOCTL_SMARTCARD_VENDOR_IFD_EXCHANGE, cmd_global, sizeof(cmd_global),  pbRecvBuffer, dwRecvLength ,&dwRecvLength);
			CHECK("SCardControl", rv)
			printf("No hay tarjeta\n");
/*			respuesta(dwRecvLength, pbRecvBuffer);*/
		}

/*		printf("reader state: 0x%04X\n", rgReaderStates.dwEventState);*/
/*		printf("current state: 0x%04X\n", rgReaderStates.dwCurrentState);*/

	}


	//Romper conexión con el lector
	rv = SCardDisconnect(hCard, SCARD_LEAVE_CARD);
	CHECK("SCardDisconnect", rv)

	//Liberar memoria
#ifdef SCARD_AUTOALLOCATE
	rv = SCardFreeMemory(hContext, mszReaders);
 	CHECK("SCardFreeMemory", rv)
#else
	free(mszReaders);
#endif
	//Liberar contexto
	rv = SCardReleaseContext(hContext);
	CHECK("SCardReleaseContext", rv)
	return 0;



}

int abrir_socket()
{

 int sock;
 if((sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0)
 {
  perror("\nImposible crear socket");
  exit(1);
 }
 return sock;

}

char *get_ip(char *host)
{
 struct hostent *hent;
 int iplen = 15;
 char *ip = (char *)malloc(iplen+1);
 memset(ip, 0, iplen+1);
 if((hent = gethostbyname(host)) == NULL)
 {
  herror("\nCan't get IP");
  exit(1);
 }

 if(inet_ntop(AF_INET, (void *)hent->h_addr_list[0], ip, iplen) == NULL)
 {
  perror("\nCan't resolve host");
  exit(1);
 }

 return ip;

}

char *build_query(char *host, char *page)
{
 char *query;
 char *getpage = page;
 char *postdata = "{\"IP\": \"1.2.3.4\", \"DroneID\": 5, \"MAC\": 43542356}";
 char *tpl = "POST /%s HTTP/1.0\r\nHost: %s\r\nContent-type: application/json\r\nContent-length: %d\r\n\r\n%s";

 query = (char *)malloc(strlen(host) + strlen(getpage) + strlen(tpl) + strlen(postdata) -5);
 sprintf(query, tpl, getpage, host, strlen(postdata), postdata);
 return query;
}
