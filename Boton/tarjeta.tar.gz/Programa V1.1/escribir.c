#include <stdio.h>
#include <stdlib.h>
#include <winscard.h>
#define TIMEOUT 1000
//Comprobación de que las funciones de la API PCSC se ejecuten correctamente
#define CHECK(f, rv) \
 if (SCARD_S_SUCCESS != rv) \
 { \
  printf(f ": %s\n", pcsc_stringify_error(rv)); \
  return -1; \
 }
void respuesta(DWORD dwRecvLength, BYTE pbRecvBuffer[]){
	int i;
	printf("response: ");
	for(i=0; i<dwRecvLength; i++)
		printf("%02X ", pbRecvBuffer[i]);
	printf("\n");
}
int main(int argc, char *argv[])
{
	if (argc < 3){
		printf("Es necesario pasar dos parámetros al menos:\n");
		printf("XX 		-Bloque a escribir\n" );
		printf("XX... 	-Datos  a introducir\n");
		exit(1);
	}
	
	
	LONG rv;	//Valor devuelto por las funciones de la API
	SCARDCONTEXT hContext;
	LPTSTR mszReaders;	//Nombre del lector
	SCARDHANDLE hCard;	//Número de lector detectado
	DWORD dwReaders, dwActiveProtocol, dwRecvLength;
 	SCARD_IO_REQUEST pioSendPci;

	BYTE pbRecvBuffer[258];	//Respuesta de la tarjeta uint8
	//EStablece contexto
	rv = SCardEstablishContext(SCARD_SCOPE_SYSTEM, NULL, NULL, &hContext);
	CHECK("SCardEstablishContext", rv)
	//Comprueba si la API tiene designación automática de memoria, para este caso lo tiene
#ifdef SCARD_AUTOALLOCATE
	dwReaders = SCARD_AUTOALLOCATE;
	//Regresa lista de lectores de tarjetasw
	rv = SCardListReaders(hContext, NULL, (LPTSTR)&mszReaders, &dwReaders);
	CHECK("SCardListReaders", rv)
#else
	rv = SCardListReaders(hContext, NULL, NULL, &dwReaders);
	CHECK("SCardListReaders", rv)
	mszReaders = calloc(dwReaders, sizeof(char));
 	rv = SCardListReaders(hContext, NULL, mszReaders, &dwReaders);
	 CHECK("SCardListReaders", rv)
#endif
	printf("reader name: %s\n", mszReaders);

	//Establece conexión  tarjetas disponibles
	rv = SCardConnect(hContext, mszReaders, SCARD_SHARE_SHARED, SCARD_PROTOCOL_T0 | SCARD_PROTOCOL_T1, &hCard, &dwActiveProtocol);
	CHECK("SCardConnect", rv)
	
	switch(dwActiveProtocol) //Dependiendo del tipo de conexión leído establece el protocolo en el que enviará los paquetes
	 {
		case SCARD_PROTOCOL_T0:
			pioSendPci = *SCARD_PCI_T0;
			break;
  		case SCARD_PROTOCOL_T1:
		   pioSendPci = *SCARD_PCI_T1;
		   break;
 	}
	//Limpia p


	//Carga llave
	BYTE cmd_auth_key[] = { 0xFF, 0x82, 0x00, 0x00, 0x06, 0xFF, 0xFF, 0xFF,
	0xFF, 0xFF, 0xFF};
	rv = SCardTransmit(hCard, &pioSendPci, cmd_auth_key, sizeof(cmd_auth_key), NULL, pbRecvBuffer, &dwRecvLength);
	CHECK("SCardTransmit", rv)
	respuesta(dwRecvLength, pbRecvBuffer);

	//Authenticate Block 04h with the following characteristics: Type A, key number 00h
	BYTE cmd_auth_sc[] = { 0xFF, 0x86, 0x00, 0x00, 0x05, 0x01, 0x00, 0x04, 0x60, 0x00 };
	rv = SCardTransmit(hCard, &pioSendPci, cmd_auth_sc, sizeof(cmd_auth_sc), NULL, pbRecvBuffer, &dwRecvLength);
	CHECK("SCardTransmit", rv)
	respuesta(dwRecvLength, pbRecvBuffer);
	return 0;
	
}
